<?php 
session_start();
//require_once('cidade.php');
$pessoas = [];
 if(isset($_SESSION['cadastrarpessoas'])){
 	$pessoas = $_SESSION['cadastrarpessoas'];
 }
 ?>

<!doctype html>
<html lang="pt-br">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="node_modules/font-awesome/css/font-awesome.min.css" rel="stylesheet">

    <title>cadastro</title>
  </head>
  <body>

  <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
	  <div class="container-fluid">
	    <a class="navbar-brand" href="#">SYST CAD</a>
	    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
	    </button>

	    <div class="collapse navbar-collapse" id="navbarSupportedContent">
	     <ul class="navbar-nav me-auto mb-2 mb-lg-0">
	        <li class="nav-item">
	          <a class="nav-link active" aria-current="page" href="index.php">Listar</a>
	        </li>
	        <li class="nav-item">
	          <a class="nav-link " aria-current="page" href="cadastrar.php">Cadastrar</a>
	        </li>
	       
	      </ul>
	     
	    </div>
	  </div>
</nav>

<body>
<div class="container" col-md-12>
<br>
<h2 align="center">Listar Conteúdo</h2>
<a href="cadastrar.php" ><button class="btn btn-success" ><i class="fa fa-plus" aria-hidden="true "> Adicionar </i></button></a>
<br>
	<div class="con tent">
<br>
		<table class="table table-hover">
			<thead>
				<tr>
					<th>Id</th>
					<th>Nome</th>
					<th>Idade</th>
					<th>Telefone</th>
					<th>Endereço</th>
					<th>Cep</th>
					<th>Cidade</th>
					<th>Estado</th>
					<th>Ação</th>
				</tr>
			</thead>
			<tbody>
<?php 		
				foreach ($pessoas as $i => $vi) {
				
					echo "<tr>";
					echo "<td>".$i."</td>";
					echo "<td>".$vi['nome']."</td>";
					echo "<td>".$vi['idade']."</td>";
					echo "<td>".$vi['telefone']."</td>";
					echo "<td>".$vi['endereco']."</td>";
					echo "<td>".$vi['cep']."</td>";
					echo "<td>".$vi['cidade']."</td>";
					echo "<td>".$vi['estado']."</td>";

					echo "<td>";
					echo '<a class="btn btn-danger" href="apagar.php?id='.$i.'"><i class="fa fa-trash fa-lg"></i></a>';
					echo '<a class="btn btn-warning" href="cadastrar.php?id='.$i.'"><i class="fa fa-pencil fa-lg"></i></a>';
					
					
	                	
					echo "</td>";
					

					echo "</tr>";
				}	
		
?>


			</tbody>





		</table>






	</div>
	


</div>




</body>
	

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="bootstrap/dist/js/bootstrap.bundle.min.js"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
 
    <script src="popper.js/dist/umd/popper.min.js"></script>
    <script src="bootstrap/dist/js/bootstrap.min.js"></script>
    
  </body>
</html>