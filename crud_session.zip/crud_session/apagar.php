<?php
session_start();
if(isset($_GET['id']) && $_GET['id'] != ''){
	$id = $_GET['id'];
	array_splice($_SESSION['cadastrarpessoas'],$id, 1);
}else{
	header('location:./index.php ');
	//echo "<h2 color='red'> ID não Encontrado</h2>";
}
	header('location:./index.php ');
?>