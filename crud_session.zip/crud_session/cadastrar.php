<?php 
session_start();
require_once('cidade.php');
 $id = '';
 $nome = '';
 $idade = '';
 $telefone = '';
 $endereco = '';
 $cep = '';
 $cidade = '';
 $estado = '';

 if(count($_GET) && $_GET['id'] != ''){

 	$id = $_GET['id'];
 	$nome = $_SESSION['cadastrarpessoas'][$id]['nome'];
 	$idade = $_SESSION['cadastrarpessoas'][$id]['idade'];
 	$telefone = $_SESSION['cadastrarpessoas'][$id]['telefone'];
 	$endereco = $_SESSION['cadastrarpessoas'][$id]['endereco'];
 	$cep = $_SESSION['cadastrarpessoas'][$id]['cep'];
 	$cidade = $_SESSION['cadastrarpessoas'][$id]['cidade'];
 	$estado = $_SESSION['cadastrarpessoas'][$id]['estado'];


 }

 ?>

<!doctype html>
<html lang="pt-br">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="node_modules/font-awesome/css/font-awesome.min.css" rel="stylesheet">

    <title>cadastro</title>
  </head>
  <body>

  <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
	  <div class="container-fluid">
	    <a class="navbar-brand" href="#">SYST CAD</a>
	    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
	    </button>

	    <div class="collapse navbar">
	    
	     
	    </div>

	    <div class="collapse navbar-collapse" id="navbarSupportedContent">
	     <ul class="navbar-nav me-auto mb-2 mb-lg-0">
	        <li class="nav-item">
	          <a class="nav-link" aria-current="page" href="index.php">Listar</a>
	        </li>
	        <li class="nav-item">
	          <a class="nav-link  active" aria-current="page" href="cadastrar.php">Cadastrar</a>
	        </li>
	       
	      </ul>
	     
	    </div>
	  </div>
</nav>


	<br>
	<br>
	<h2 align="center">Cadastrar Usuário</h2>
	<br>
<form class="" method="post" action="salvar.php">

<div class="container" col-md-12>
	 <div class="form-group" col-md-12>
	 	<input type="hidden" name="id" value="<?php echo $id;?>">
	    <label for="nome">Nome</label>
	    <input type="text" class="form-control" id="nome" aria-describedby="nome" value="<?php echo $nome; ?>" name="nome" placeholder="nome da pessoas">
	  </div>
		<div class="row" col-md-12>
		  <div class="col" col-ms-4>
		    <label for="idade">Idade</label>
		    <input type="text" name="idade" class="form-control" id="idade" aria-describedby="idade" value="<?php echo $idade; ?>"  placeholder="idade da pessoas">
		  </div>
		  <div class="col" col-ms-8>
		    <label for="telefone">Telefone</label>
		    <input type="text" name="telefone" class="form-control" id="telefone" aria-describedby="telefone" value=" <?php echo $telefone; ?>"  placeholder="telefone da pessoas">
		  </div>
	  	</div>
	  	<div class="form-group">
	    <label for="endereco">Endereco</label>
	    <input type="text" name="endereco" class="form-control" id="endereco" aria-describedby="endereço" value="<?php echo $endereco; ?>"  placeholder="endereço da pessoas">
	  </div>
	  <div class="row">
		    <div class="col">
		    <label for="idade">CEP</label>
		    <input type="text" name="cep" class="form-control" id="idade" aria-describedby="idade" value="<?php echo $cep; ?>"  placeholder="idade da pessoas">
		  </div>
		  <div class="col">
		    <label for="cidade">Cidade</label>
		    <input type="text" name="cidade" class="form-control" id="cidade" aria-describedby="cidade" value="<?php echo $cidade; ?>"  placeholder="cidade da pessoas">
		  </div>
		  <div class="col">
		    <label for="estado">Estado</label>
		    <select id="estado" value="<?php echo $estado; ?>"  name="estado" class="form-control">

<?php 

 			foreach ($estados as $i => $uf) {
 				echo "<option value =\"$uf\" selected'>".$uf."</option>";
 			}
 
 ?>
		    	
		    	
		    </select>
		  </div>
	  	</div>
	  	<br>
	  	<br>
	  <button type="submit" class="btn btn-primary">Enviar</button>
	   <button type="reset" class="btn btn-warning">Limpar</button>
	  </div>
</form>
	



	






    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="bootstrap/dist/js/bootstrap.bundle.min.js"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
 
    <script src="popper.js/dist/umd/popper.min.js"></script>
    <script src="bootstrap/dist/js/bootstrap.min.js"></script>
    
  </body>
</html>