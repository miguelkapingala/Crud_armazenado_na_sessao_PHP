<?php

session_start();

if(isset($_POST['id']) && $_POST['id'] != ''){

	$id = $_POST['id'];
 	$_SESSION['cadastrarpessoas'][$id]['nome']		=$_POST['nome'];
 	$_SESSION['cadastrarpessoas'][$id]['idade']		=$_POST['idade'];
 	$_SESSION['cadastrarpessoas'][$id]['telefone']	=$_POST['telefone'];
 	$_SESSION['cadastrarpessoas'][$id]['endereco']	=$_POST['endereco'];
 	$_SESSION['cadastrarpessoas'][$id]['cep']		=$_POST['cep'];
 	$_SESSION['cadastrarpessoas'][$id]['cidade']	=$_POST['cidade'];
  	$_SESSION['cadastrarpessoas'][$id]['estado']	=$_POST['estado'];



}elseif(count($_POST)){

	$_SESSION['cadastrarpessoas'][] = $_POST;

}
//var_dump($_POST);
header('Location:./index.php');
 ?>

