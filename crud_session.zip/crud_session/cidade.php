<?php

//$cidade = ['Acre','Alagoas', 'Amazonas', 'Amapá','Bahia','Ceará','Distrito Federal','Espírito Santo','Goiás','Maranhão','Mato ','Mato Grosso do Sul','Minas Gerais','Pará','Paraíba','Paraná','Pernambuco','Piauí','Rio de Janeiro','Rio Grande do Norte','Rondônia','Rio Grande do Sul','Roraima','Santa Catarina','Sergipe','São Paulo','Tocantins'];

$estados = ['AC','AL','AP ','AM','BA','CE ','DF ','ES ','GO ','MA ','MS ','MT ','MG ','PA','PB','PR','PE','PI','RJ','RN','RS','RO','RR','SC','SP','SE','TO']; 
?>